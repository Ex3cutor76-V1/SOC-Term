#!/usr/bin/env bash

# Cores
VERMELHO=$'\033[31m'
VERDE=$'\033[32m'
CIANO=$'\033[36m'
AMARELO=$'\033[33m'
RESET=$'\033[0m'

# Verificação se a ferramenta está usando root

if [ "$(id -u)" -ne 0 ]; then
    printf "${VERMELHO}Acesso negado${RESET}\n"
    echo "Utilize: sudo sct -h"
    exit 1
fi

# Diretório dos scripts
SOC_DIR="/opt/SOC-Term"
SCRIPT_DIR="$SOC_DIR/scripts"
CENTRAL_SCRIPT="/usr/local/bin/sct"

case "$1" in

-h)

cat << EOF

SOC-Term - Ferramenta para análise de segurança

Uso:
sct <flag> <argumento>

Apoio:
-h              Mostra ajuda
-db             Consulta das strings
--log           Consulta de logs
-v              Mostra versão da ferramenta
--upgrade       Atualizar a ferramenta

Usuários:
-u              Mostra uma lista de usuários existentes no sistema

Arquivos:
-st <arquivo>   Análise de strings
-a  <arquivo>   Análise de Hash
-i  <arquivo>   Informações sobre um arquivo

Logs:
-ssh            Logs SSH
-sys            Logs do sistema
-svc            Logs de serviços
-krn            Logs do kernel

Serviços:
-se             Análise de serviços


Processos:
-pr             Análise de processos


Rede:
-p              Análise de portas TCP/UDP
-l              Análise de recursos usando lsof

EOF

;;

-st)

if [ -z "$2" ]; then
    printf "${VERMELHO}Erro: informe um arquivo.${RESET}\n"
    exit 1
fi

if [[ ! -f "$2" ]]; then
    printf "${VERMELHO}Arquivo inexistente.${RESET}\n"
    exit 1
fi

printf "${CIANO}Permissões do arquivo${RESET}\n"
ls -lh "$2"

bash "$SCRIPT_DIR/string.sh" strings "$2"

;;


-ssh)

bash "$SCRIPT_DIR/logs.sh" -ssh

;;


-sys)

bash "$SCRIPT_DIR/logs.sh" -sys

;;


-svc)

bash "$SCRIPT_DIR/logs.sh" -svc

;;

-krn)

bash "$SCRIPT_DIR/logs.sh" -krn

;;

-se)

bash "$SCRIPT_DIR/services.sh"

;;


-pr)

bash "$SCRIPT_DIR/process.sh"

;;


-p)

bash "$SCRIPT_DIR/ports.sh"

;;


-l)

sudo lsof -i -n -P

;;

-db)
bash "$SCRIPT_DIR/db.sh"

;;

--log)
bash "$SCRIPT_DIR/logviewer.sh"
;;

-v)
echo "Nome: SOC-Term"
echo "Versão 4.1"
;;

-u)
bash "$SCRIPT_DIR/user.sh"
;;

-i)
bash "$SCRIPT_DIR/info.sh" info "$2"
;;

-a)
bash "$SCRIPT_DIR/hash.sh" hash "$2"
;;

--upgrade)
printf "${AMARELO}Instalando nova versão...${RESET}\n"
git clone https://github.com/Ex3cutor76-V1/SOC-Term.git
printf "${AMARELO}Testando existência de arquivos...${RESET}\n"
sleep 1
if [[ -d "$SOC_DIR" ]]; then
printf "${VERDE}Diretório encontrado${RESET}\n"
else
printf "${VERMELHO}Diretório não encontrado${RESET}\n"
fi
if [[ -f "$CENTRAL_SCRIPT" ]]; then
printf "${VERDE}Arquivo encontrado!${RESET}\n"
else
printf "${VERMELHO}Arquivo não encontrado${RESET}\n"
fi
printf "${AMARELO}Removendo arquivos antigos...${RESET}\n"
sudo rm -rf "$SOC_DIR"
sudo rm -rf "$CENTRAL_SCRIPT"
printf "${AMARELO}Reorganizando SOC-Term...${RESET}\n"
cd SOC-Term
sudo ./install.sh
printf "${VERDE}Atualização completa!${RESET}\n"
;;

*)
printf "${VERMELHO}Comando inválido.${RESET}\n"
printf "${CIANO}Use: sudo sct -h${RESET}\n"

;;

esac
