#!/usr/bin/env bash

# Cores
VERDE=$'\033[33m'
AMARELO=$'\033[32m'
RESET=$'\033[0m'

# Variável importante
malware=$2
collect=$(objdump -d "$malware" | less)
atual=$(pwd)
nome=$(basename -- "$malware")
 saida="${nome}-$(date +%F-%H%M%S).asm"

if [[ -z "$malware" || ! -f "$malware" ]]; then
    printf "${VERMELHO}Arquivo inválido.${RESET}\n"
    exit 1
fi

if ! command -v objdump >/dev/null 2>&1; then
    echo "objdump não encontrado."
    exit 1
fi

# Mensagem de aviso
printf "${AMARELO}Coletando script assembly do binário...${RESET}\n"

# Coleta temporária
tmp=$(mktemp) || exit 1

if ! objdump -d -- "$malware" > "$tmp"; then
    printf "${VERMELHO}Falha na coleta.${RESET}\n"
    rm -f -- "$tmp"
    exit 1
fi

# Visualização interativa
less "$tmp"

# Salvando...
read -p "Gostaria de salvar o arquivo?(s/n): " resp
resp=${resp,,}

if [[ "$resp" == "s" ]]; then
printf "${AMARELO}Salvando no seu diretório atual...$atual${RESET}\n"
objdump -d "$malware" > "$saida"
printf "${VERDE}Assembler salvo com sucesso!${RESET}\n"
echo "Caso queira ler o arquivo, use: sudo sct -as"
else
echo "O arquivo não foi salvo."
fi
