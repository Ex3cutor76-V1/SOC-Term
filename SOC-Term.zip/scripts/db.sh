#!/usr/bin/env bash

# Cores
MAGENTA=$'\033[35m'
VERMELHO=$'\033[31m'
CIANO=$'\033[36m'
VERDE=$'\033[32m'
AMARELO=$'\033[33m'
RESET=$'\033[0m'

# Funções importantes
ip_consulta() {
if [[ -f /opt/SOC-Term/data/ip.txt ]]; then
printf "${VERDE}O arquivo existe!${RESET}\n"
printf "${AMARELO}Lendo arquivo...${RESET}\n"
sleep 1
printf "${MAGENTA}======IP======${RESET}\n"
less /opt/SOC-Term/data/ip.txt
else
printf "${VERMELHO}O arquivo não existe...${RESET}\n"
fi
}

mail_consulta() {
if [[ -f /opt/SOC-Term/data/mail.txt ]]; then
printf "${VERDE}O arquivo existe!${RESET}\n"
printf "${AMARELO}Lendo arquivo...${RESET}\n"
sleep 1
printf "${MAGENTA}======Email======${RESET}\n"
less /opt/SOC-Term/data/mail.txt
else
printf "${VERMELHO}O arquivo não existe${RESET}\n"
fi
}

url_consulta() {
if [[ -f /opt/SOC-Term/data/url.txt ]]; then
printf "${VERDE}O Arquivo existe!${RESET}\n"
printf "${AMARELO}Lendo arquivo...${RESET}\n"
sleep 1
printf "${MAGENTA}======URL======${RESET}\n"
less /opt/SOC-Term/data/url.txt
else
printf "${VERMELHO}O arquivo não existe${RESET}\n"
fi
}

# Começo da consulta
while true; do
ls -lh /opt/SOC-Term/data/

printf "${MAGENTA}Digite 'q' para sair${RESET}\n"
read -p "${CIANO}Qual arquivo gostaria de ler?:${RESET} " arq 
arq=${arq,,}
printf "${AMARELO}Iniciando consulta...${RESET}\n"
sleep 1

case "$arq" in

# Consulta de IP
ip)
ip_consulta
;;
# Consulta de Email
mail)
mail_consulta
;;
# Consulta de URL
url)
url_consulta
;;
clear)
printf "${AMARELO}Fazendo a limpeza...${RESET}\n"
sudo rm -f /opt/SOC-Term/data/*.txt
;;
q)
printf "${AMARELO}Terminando a consulta...${RESET}\n"
sleep 1
break
;;
*)
printf "${VERMELHO}Opção inválida${RESET}\n"
;;

esac
done
